var searchData=
[
  ['fliphorizontal',['flipHorizontal',['../class_i_n_d___image.html#a6b69b0a9c80493ea147f46917de09bdb',1,'IND_Image']]],
  ['flipvertical',['flipVertical',['../class_i_n_d___image.html#ac65439902d65f8349c333e86cb9c73e9',1,'IND_Image']]]
];
