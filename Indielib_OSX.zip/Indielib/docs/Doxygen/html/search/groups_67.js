var searchData=
[
  ['global_20constants',['Global constants',['../group___global_constants.html',1,'']]],
  ['graphical_20objects_20_28that_20can_20be_20inserted_20into_20the_20entities_29',['Graphical Objects (that can be inserted into the entities)',['../group___objects.html',1,'']]]
];
