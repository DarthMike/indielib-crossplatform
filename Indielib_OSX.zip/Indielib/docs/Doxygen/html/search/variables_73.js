var searchData=
[
  ['sides_5fper_5fcircle',['SIDES_PER_CIRCLE',['../group___global_constants.html#ga12e7788a00fae88445dddc7c49beb9ca',1,'Defines.h']]]
];
