var searchData=
[
  ['debug_20mode',['Debug mode',['../group___i_n_d___debug.html',1,'']]]
];
